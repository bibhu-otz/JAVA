package GST;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Date;
public class GSTBillingSystem {
	  static Scanner scanner = new Scanner(System.in);
      static List<Product> products = new ArrayList<>();
      static List<Customer> customers = new ArrayList<>();
      static List<Invoice> invoices = new ArrayList<>();
      static int productCounter = 1;
      static int customerCounter = 1;
      static int invoiceCounter = 1;

    public static void main(String[] args) {
      
        while (true) {
            // Menu for user actions (e.g., add products, customers, create invoices)
        	displayMenu();
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            if (option == 10) {
                break;
            }
            switch (option) {
                case 1:// Add Product
                	addProduct();
                    break;
                case 2: //View Product
                	System.out.println("View Products");
                	new Product().getAllProducts(products);
                	break;
                case 3://Update Product
                	System.out.println("Enter ProductID to Update :");
                	
                	int pid =scanner.nextInt();
                	products=new Product().updateProduct(pid, products);
                   break;
                case 4://Delete Product
                	
                	System.out.println("Enter ProductID to Delete :");
                	int pid1 = scanner.nextInt();
                	products=new Product().deleteProduct(pid1,products);
                	break;
                case 5://Add Customer
                    addCustomer();
                    break;
                
                case 6://View Customer
                	new Customer().getAllCustomers(customers);
                    break;
                case 7://Update Customer
                	System.out.println("Enter CustomerID to Update :");
                    int cid =scanner.nextInt();
                	customers=new Customer().updateCustomer(cid, customers);
                	break;
                case 8 ://Delete Customer
                	System.out.println("Enter CustomerID to Delete :");
                	int cid1 = scanner.nextInt();
                	customers=new Customer().deleteCustomer(cid1,customers);
                	break;

                case 9:
                    if (products.isEmpty() || customers.isEmpty()) 
                    {
                        System.out.println("Please add products and customers before creating an invoice.");
                        break;
                    }

                    System.out.print("Select a customer by entering the customer ID: ");
                    int selectedCustomerId = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character
                    
                    Customer selectedCustomer = null;
                    for (Customer customer : customers) {
                        if (customer.getCustomerId() == selectedCustomerId) {
                            selectedCustomer = customer;
                            break;
                        }
                    }
                    if (selectedCustomer == null) {
                        System.out.println("Customer not found.");
                        break;
                    }
                    
                    Date date = new Date();
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
                    String str = formatter.format(date);
                    Invoice newInvoice = new Invoice(invoiceCounter, selectedCustomer,str);
                    invoiceCounter++;
                    String choice="";
                    do{
                        System.out.print("Select a product to add to the invoice by entering the product ID (or enter 0 to finish): ");
                        int selectedProductId = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character
                        Product selectedProduct = null;
                        for (Product product : products) {
                            if (product.getProductId() == selectedProductId) {
                                selectedProduct = product;
                                break;
                            }
                        }

                        if (selectedProduct != null) {
                            System.out.print("Enter quantity: ");
                            int quantity = scanner.nextInt();
                            scanner.nextLine(); // Consume the newline character
                            selectedProduct.setQuantity(quantity);
                            newInvoice.addProduct(selectedProduct);
                            System.out.println("Product added to the invoice.");
                        }else {
                        	System.out.println("Product not Found !!");
                        } 
                        System.out.println("do you want to add more Product(Y/N):");
                        choice =scanner.nextLine() ;
                    }while(choice.equals("Y"));
                    invoices.add(newInvoice);
                    printInvoice();
                    break;
            }
            
        }

       
    }
    static void printInvoice() {
    	 // Display all invoices
        System.out.println("Invoices:");
        for (Invoice invoice : invoices) {
            System.out.println("Invoice ID: " + invoice.invoiceId);
            System.out.println("Customer: " + invoice.customer.getName());
            //System.out.println("Total Amount: $" + invoice.calculateTotalAmount());
            System.out.println("-------------------------");
            invoice.generateBill(invoice.items);
        }
    }
    static void displayMenu() {
    	System.out.println("---------------------------------------------------------------");
    	System.out.println("\t\tGST BILLING APPLICATION");
    	System.out.println("---------------------------------------------------------------\n");
    	System.out.println("********************** MANAGE PRODUCT *************************");
    	System.out.println("1. Add Product");
        System.out.println("2. View Product");
        System.out.println("3. Update Product");
        System.out.println("4. Delete Product");
        System.out.println("********************** MANAGE CUSTOMER *************************");
        System.out.println("5. Add Customer");
        System.out.println("6. View Customer");
        System.out.println("7. Update Customer");
        System.out.println("8. Delete Customer");
        System.out.println("**********************GENERATE INVOICE**************************");
        System.out.println("9.Create Invoice");
        System.out.println("10.Exit");
        System.out.println("--------------------------------------------------------------");
        System.out.print("Select an option: ");
    }
    static void addProduct() {
    	System.out.print("Enter product name: ");
        String productName = scanner.nextLine();
        System.out.print("Enter product description: ");
        String productDescription = scanner.nextLine();
        System.out.print("Enter product price: ");
        double productPrice = scanner.nextDouble();
        System.out.print("Enter GST rate: ");
        double productGstRate = scanner.nextDouble();
        scanner.nextLine();
        Product newProduct = new Product(productCounter, productName, productDescription, productPrice, productGstRate);
        products.add(newProduct);
        productCounter++;
        System.out.println("Product added.");
    }
    static void addCustomer() {
    	System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter customer contact information: ");
        String customerContactInfo = scanner.nextLine();
        System.out.print("Enter customer GST number (if applicable): ");
        String customerGstNumber = scanner.nextLine();

        Customer newCustomer = new Customer(customerCounter, customerName, customerContactInfo, customerGstNumber);
        customers.add(newCustomer);
        customerCounter++;
        System.out.println("Customer added.");
    }

}

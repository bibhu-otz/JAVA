package GST;

import java.util.ArrayList;
import java.util.List;

public class Invoice {
    int invoiceId;
    Customer customer;
    List<Product> items;
    String invoiceDate;

   public Invoice(int invoiceId, Customer customer, String invoiceDate) {
       this.invoiceId = invoiceId;
       this.customer = customer;
       this.invoiceDate = invoiceDate;
       this.items = new ArrayList<>();
   }

   public void addProduct(Product product) {
       // Add a product and quantity to the invoice
       items.add(product);
   }

   public double calculateTotalAmount() {
       double totalAmount = 0;
       for (Product product : items) {
           totalAmount += product.calculateTotalPrice(product.getQuantity());
       }
       return totalAmount;
   }
   public void generateBill(List<Product> products) {
       System.out.println("Invoice:");
       System.out.println("ProductId\\t\\tProductName\t\tPrice\tQuantity\tGST\tTotal");
       System.out.println("-----------------------------------------------------------------------------------");
       for (Product product : products) {
           System.out.println(product.getProductId()+"\t\t"+product.getName()+"\t\t"+product.getPrice()+"\t\t"+product.getQuantity()+"\t\t"+product.getGstRate()+"\t\t"+product.calculateTotalPrice(product.getQuantity()));
       }
       System.out.println("-----------------------------------------------------------------------------------");
       System.out.println("Total Amount: $" + calculateTotalAmount());
   }
}

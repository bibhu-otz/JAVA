package GST;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Customer {
	private int customerId;
	private String name;
	private String contactInfo;
	private String gstNumber;
     public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

    public Customer() {}
	public Customer(int customerId, String name, String contactInfo, String gstNumber) {
        this.customerId = customerId;
        this.name = name;
        this.contactInfo = contactInfo;
        this.gstNumber = gstNumber;
    }
    
    public void getAllCustomers(List<Customer> customers){
    	
    	System.out.println("customerId | Name | ContactInfo | GST Number ");
    	System.out.println("----------------------------------------------");
    	for(Customer customer : customers) {
    		
    		System.out.println(customer.customerId+" | "+customer.name+" | "+customer.contactInfo+" | "+customer.gstNumber);
    		
    	}
    	System.out.println("-----------------------------------------------");
    }
    
    public List<Customer> updateCustomer(int customerId,List<Customer> customers){
    	
    	for(Customer customer : customers) {
    		if(customer.getCustomerId() == customerId) {
    			Scanner sc = new Scanner(System.in);
    			System.out.println("Update Customer Name :");
    			customer.setName(sc.nextLine());
    			System.out.println("Update Customer ContactInfo :");
    			customer.setContactInfo(sc.nextLine());
    			System.out.println("Update GST Number :");
    			customer.setGstNumber(sc.nextLine());
    			System.out.println("Customer Record Updated Successfully !!!");
    		}
    	}
    	
    	return customers;
    }
    
    public List<Customer> deleteCustomer(int customerID,List<Customer> customers){
    	
    	for(Iterator<Customer> itr = customers.iterator();itr.hasNext();){            
    		Customer customer =itr.next();            
			if(customer.getCustomerId() == customerId){
			itr.remove(); // right call
			System.out.println("Customer Deleteded Successfully !!!");
		  }
		}
		    	
		return customers;
    }
}


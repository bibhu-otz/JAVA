package GST;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Product {
	private int productId;
	private  String name;
	private  String description;
	private  double price;
	private  double gstRate;
	private  int quantity;

    public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getGstRate() {
		return gstRate;
	}

	public void setGstRate(double gstRate) {
		this.gstRate = gstRate;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
        return name;
    }
	
	//Constructor
	public Product() {};
    public Product(int productId, String name, String description, double price, double gstRate) {
        this.productId = productId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.gstRate = gstRate;
    }

    public double calculateTotalPrice(int quantity) {
        return price * quantity * (1 + gstRate / 100);
    }
    
    public void getAllProducts(List<Product> products){
    	System.out.println("ProductID | Product Name | Description | Price | Rate");
    	System.out.println("--------------------------------------------------------------");
    	for(Product prod : products) {
    		
    		System.out.println(prod.productId+" | "+prod.name+" | "+prod.description+" | "+prod.price+" | " +prod.gstRate);
    		
    	}
    	System.out.println("--------------------------------------------------------------");
    }

    public List<Product> updateProduct(int productID,List<Product> products){
    	for(Product prod : products) {
    		if(prod.getProductId() == productID) {
    			Scanner sc = new Scanner(System.in);
    			System.out.println("Update Product Name :");
    			prod.setName(sc.nextLine());
    			System.out.println("Update Product Description :");
    			prod.setDescription(sc.nextLine());
    			System.out.println("Update Product Price :");
    			prod.setPrice(sc.nextFloat());
    			System.out.println("Update Product GSTRate :");
    			prod.setGstRate(sc.nextFloat());
    			System.out.println("Product Updated Successfully !!!");
    		}
    	}
    	
    	return products;
    }
    public List<Product> deleteProduct(int productID,List<Product> products){
    	
        for(Iterator<Product> itr = products.iterator();itr.hasNext();){            
		    	Product prod =itr.next();            
				if(prod.getProductId() == productID){
				itr.remove(); // right call
				System.out.println("Product Deleteded Successfully !!!");
			  }
		}
		    	
    	return products;
    }
    
}
